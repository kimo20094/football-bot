import requests
import time
import telegram
from bs4 import BeautifulSoup

TOKEN = "7590737605:AAH-knOYVH2UUtebQfkVC089ugvpusgNb6A"
CHANNEL_ID = "@co1ombia_clan"

bot = telegram.Bot(token=TOKEN)
sent_headlines = set()

def get_news():
    url = "https://www.goal.com/en"
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    articles = soup.find_all('a', class_='type-article')[:5]
    news = []
    for article in articles:
        title = article.get_text(strip=True)
        link = "https://www.goal.com" + article.get('href')
        if title and title not in sent_headlines:
            news.append((title, link))
            sent_headlines.add(title)
    return news

def send_news():
    news_list = get_news()
    for title, link in news_list:
        bot.send_message(chat_id=CHANNEL_ID, text=f"🏟️ {title}\n🔗 {link}")

while True:
    try:
        send_news()
    except Exception as e:
        print(f"حدث خطأ: {e}")
    time.sleep(600)